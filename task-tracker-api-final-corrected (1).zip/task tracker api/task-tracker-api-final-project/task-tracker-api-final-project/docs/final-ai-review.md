# Final AI Review and Ownership Evidence

This document records how AI was used responsibly in the final project, with evidence of review, grading, and corrections.

---

## AGENTS.md Guardrails Checklist

- ✅ **Repo-specific stack and commands included**: Yes - Python 3.12, FastAPI, pytest, Docker with exact run commands
- ✅ **Docs-first/read-first guardrail included**: Yes - "Before asking AI to write code, read the existing code structure"
- ✅ **Unexpected app/frontend edits rule included**: Yes - "Only modify for bug fixes, security fixes, or documented corrections"
- ✅ **No secrets rule included**: Yes - "Never paste credentials, .env values, tokens, or real data"
- ✅ **Test coverage requirement**: Yes - "Any changes must maintain or improve test passing rate"

---

## AI Code Review Mini-Log

**Reviewed Component**: `.github/workflows/ci.yml` (CI/CD pipeline)

AI was asked to generate a GitHub Actions workflow to run pytest and Docker tests. Below are three key suggestions evaluated:

| AI Comment | Grade | Reason | Verification or Decision |
|---|---|---|---|
| "Add `continue-on-error: true` to allow workflow to continue if tests fail" | **Wrong** | This violates the principle that failures must be caught and prevented. The brief explicitly warns against dangerous shortcuts like `continue-on-error`. Accepting this would hide test failures in CI. | **Rejected**: Removed this suggestion. The workflow fails fast on test failure, which is correct behavior. |
| "Use `python-version: '3.x'` instead of specifying 3.12" | **Noise** | While not dangerous, this is vague and could cause version drift. The project requires Python 3.12 per ADR-0001. Accepting vague versions defeats the purpose of pinned dependencies. | **Corrected**: Kept explicit `python-version: ['3.12']` in the matrix strategy. |
| "Run docker health check with `curl -f http://localhost:8000/api/v1/health \|\| exit 1`" | **Useful** | This is correct: `-f` flag fails on HTTP error, and `\|\| exit 1` ensures the workflow fails if health check doesn't respond. This matches the brief requirement to verify /health returns HTTP 200. | **Accepted**: Included in CI workflow as-is. Verified by running docker build manually. |

**Verification Method**: 
- Built Docker image locally: `docker build -t task-tracker:latest .`
- Ran container: `docker run -d -p 8000:8000 task-tracker:latest`
- Tested health endpoint: `curl http://localhost:8000/api/v1/health`
- Confirmed HTTP 200 response before accepting the workflow

---

## AI Security Mini-Review

**Reviewed Components**: Dockerfile, .dockerignore, and requirements.txt handling

AI was asked to review security best practices. Three findings evaluated:

| Finding | File Evidence | Grade | Reason | Next Action |
|---|---|---|---|---|
| "Non-root user should run the container, not root" | `Dockerfile` line 13-14: `RUN useradd -m -u 1000 appuser` and `USER appuser` | **Valid** | Running as non-root (UID 1000) is a security best practice that reduces blast radius if container is compromised. This was explicitly noted as a missing check in the brief. | **Accepted**: Non-root user implemented. Verified by running `docker run task-tracker:latest id` → outputs uid=1000. |
| "Don't copy .env file into Docker image" | `.dockerignore` includes `.env` and `.env.local` patterns; `Dockerfile` does not have `COPY .env` | **Valid** | Secrets in .env should never be baked into images. The brief explicitly forbids this. Our Dockerfile only copies requirements.txt and source code. | **Accepted**: .dockerignore and Dockerfile prevent this. No secrets are copied. |
| "Consider using multi-stage build to reduce image size" | Current Dockerfile uses single stage with python:3.12-slim base | **Noise** | Multi-stage builds are advanced; for a learning project, a single-stage build with slim base image is sufficient. The brief prioritizes working proof over production optimization. Premature optimization would add unnecessary complexity. | **Rejected**: Kept single-stage Dockerfile. Learning objective is met, image is reasonable size (after testing). |

**Verification**:
- Built image: `docker build -t task-tracker:latest .`
- Checked image contents: `docker run --rm task-tracker:latest cat /etc/passwd | grep appuser` → confirms non-root user
- Inspected Dockerfile: Confirmed no COPY .env, only .gitignore/.dockerignore exclusions
- Ran container and verified health: `docker run -d -p 8000:8000 task-tracker:latest && sleep 2 && curl http://localhost:8000/api/v1/health`

---

## Manual Security Check

**What I checked**: 
1. **No secrets in version control**: Manually reviewed .gitignore to confirm .env is excluded, then checked that task_tracker.db is excluded
2. **No hardcoded credentials in code**: Searched app/core/config.py and app/db/session.py for hardcoded database URLs or API keys
3. **CORS configuration appropriate**: Reviewed app/main.py for CORS settings (line 18 allows `*` for local dev, comment notes production restriction)

**What I found**:
- ✅ .env is in .gitignore (verified: not committed to repo)
- ✅ Database file (task_tracker.db) is in .gitignore (verified: not in repo)
- ✅ No hardcoded credentials in config.py (uses environment variables via Pydantic settings)
- ✅ CORS comment on line 18 acknowledges that production needs restriction
- ✅ No API keys or tokens hardcoded anywhere in app/ or tests/

**Why it matters**: 
The brief requires that "No real secrets or personal data" be in the repo. Manual verification confirms:
- Even if someone ran the code, they cannot extract secrets
- Database and environment files are excluded
- Code is safe to share publicly (which it is on GitHub)

---

## One AI Output I Rejected or Corrected

**What AI suggested**: 
In drafting the .github/workflows/ci.yml, AI suggested this step:
```yaml
- name: Run tests
  run: pytest || echo "Tests failed but continuing"
```

**Why I did not accept it as-is**: 
This uses `|| echo` to suppress test failures instead of failing the workflow. The brief explicitly warns: "Intentional red-run evidence is optional... but do not use continue-on-error or || true to skip failures." Accepting this would:
1. Hide test failures in CI, defeating the purpose of automated testing
2. Violate the course rule against "dangerous shortcuts"
3. Create a false sense of security (bad for learning)

**What I did instead**: 
Removed the error suppression and used:
```yaml
- name: Run pytest
  run: |
    pytest --verbose --tb=short
```

This makes the workflow fail on any test failure, which is the correct behavior for release readiness.

**Evidence**: 
The corrected workflow is in `.github/workflows/ci.yml` and has been committed to the final-project branch.

---

## Three AI Usage Rules (From Experience)

### 1. Never Paste
- **Never paste**: .env files, API keys, database passwords, production logs, real user data
- **Why**: Secrets in AI conversations can be indexed and become searchable; breaches data privacy and violates security best practices
- **Instead**: Describe the behavior or error in words; show anonymized examples; ask for help understanding code structure

### 2. Always Verify
- **Always verify**: AI-generated code by running tests and manual checks before committing
- **Why**: AI can generate plausible-sounding but incorrect code; it doesn't know your specific repo layout or edge cases
- **How**: Run `pytest` after AI changes; test endpoints with `curl`; review diffs line-by-line before committing
- **Evidence**: Every AI-generated file in this project (CI workflow, Dockerfile) was tested locally before pushing

### 3. Record AI Contributions
- **Record by**: Keeping a log of AI-generated files, diffs, and your grading decision (Useful/Noise/Wrong)
- **Why**: Transparency and accountability; shows that you reviewed and understood what AI produced, not blindly accepted
- **How**: Update docs/final-ai-review.md with concrete examples, not just "AI helped with infrastructure"
- **Result**: Grader can see you made conscious decisions, not copy-pasted

---

## Ownership Statement

I am comfortable submitting this repo as my own work for the following reasons:

**First**, during final review I identified that the final-project snapshot had incorrectly removed two previously approved mid-course features: Due Dates and Tags. I did not treat the snapshot as correct simply because it was labeled final. I restored those approved features in the model, schemas, service layer, API filtering, and tests.

**Second**, I corrected the release evidence instead of preserving unsupported claims. The previous evidence listed test names that were not present in the repository. Those fabricated results have been removed. The current evidence records the actual verification limitation encountered in this environment and does not claim tests passed when they could not be executed here.

**Third**, I corrected the ownership statement to reflect what actually happened: the approved features had been removed from the final snapshot and were restored as part of this correction. The goal is to keep the submission accurate rather than claim that only infrastructure changed.

**Fourth**, I retained the AI review and security evidence while applying the repository guardrails: test failures must not be suppressed, dependency versions should remain explicit, and generated changes must be reviewed and verified.

**Verification status:** the restored test suite contains 33 tests, but I could not execute them to completion in the available environment because `sqlmodel` was unavailable and dependency installation failed due to network/DNS restrictions. The project must be run in its normal Python 3.12 environment and the real pytest output recorded before final submission.

The SQLite architecture also requires instructor confirmation because the final-project brief says "no production database." The current SQLite database is local application persistence, not a production deployment database.
