# Release Evidence - Final Project

## Baseline and Correction

**Branch**: final-project  
**Correction date**: 2026-08-27

The final-project snapshot had removed the two approved mid-course features: Due Dates and Tags. The implementation has now been restored in the model, schemas, service layer, API filtering, and tests.

### Restored Due Dates

- `TaskCreate` accepts an optional ISO 8601 `due_date`.
- `TaskUpdate` supports changing or clearing `due_date`.
- `TaskRead` returns `due_date` and a dynamically calculated `is_overdue` value.
- Overdue means the due date is in the past and the task is not completed.
- `filter=overdue` returns only overdue, unfinished tasks.

### Restored Tags

- `TaskCreate` accepts an optional list of tags.
- Tags are trimmed, duplicate values are removed, and empty/whitespace-only values are rejected.
- `TaskUpdate` supports replacing tags, including setting them to an empty list.
- `TaskRead` returns tags as a list.
- `tag=<value>` filters tasks without modifying stored data.

## Test Verification

**Intended command**:
```bash
pytest
```

The restored suite contains **33 test cases** (15 existing tests plus 18 tests covering the restored Due Dates and Tags behavior).

### Actual verification output in the available environment

The suite could **not be executed to completion in this environment** because the uploaded project environment did not have `sqlmodel` installed. The exact collection failure was:

```text
ImportError while loading conftest '/mnt/data/task_tracker_work/task tracker api/task-tracker-api-final-project/task-tracker-api-final-project/conftest.py'.
conftest.py:3: in <module>
    from sqlmodel import SQLModel, create_engine, Session
E   ModuleNotFoundError: No module named 'sqlmodel'

1 error during collection
```

I then attempted to install the pinned dependencies with:

```bash
python -m pip install -r requirements.txt
```

That installation could not proceed because this execution environment has no network/DNS access:

```text
ERROR: Could not find a version that satisfies the requirement fastapi==0.109.0
ERROR: No matching distribution found for fastapi==0.109.0
```

Therefore, **no passing test count is claimed here**. Run `pytest` in the project's normal Python 3.12 environment after installing `requirements.txt` and replace this section with the resulting real pytest output before submission.

## Documentation Correction

The previous release-evidence file listed test names that were not present in the actual repository. Those fabricated results have been removed.

The current evidence must only report test names and results produced by the actual `pytest` command.

## Ownership Statement

The final AI review has been corrected to acknowledge that the final-project snapshot had removed two previously approved features and that this correction restores them.

## Architecture Clarification Required

The application uses SQLite through SQLModel (`app/db/session.py`). The database is a local application/test persistence mechanism, not a production deployment database.

Because the final-project brief says **"no production database"**, instructor confirmation is still required that local SQLite persistence is acceptable under the course's intended architecture. This repository does not claim that the database requirement has been waived.

## CI/CD and Docker

The existing CI workflow and Docker configuration remain part of the release infrastructure. Their behavior should be re-verified after the restored feature code is committed and the full test suite passes in the project's normal environment.
