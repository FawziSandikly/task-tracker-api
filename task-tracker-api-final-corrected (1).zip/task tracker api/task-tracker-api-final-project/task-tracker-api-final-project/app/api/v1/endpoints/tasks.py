# Task endpoints implementing CRUD operations per ADR-0001 and approved mid-course features
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import Session

from app.db.session import get_session
from app.schemas.task import TaskCreate, TaskRead, TaskUpdate
from app.services.task_service import TaskService

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.post("/", response_model=TaskRead)
def create_task(task_create: TaskCreate, session: Session = Depends(get_session)):
    """Create a new task."""
    return TaskService.create_task(session, task_create)


@router.get("/", response_model=list[TaskRead])
def list_tasks(
    filter: str | None = Query(default=None),
    tag: str | None = Query(default=None),
    session: Session = Depends(get_session),
):
    """List tasks, optionally filtering for overdue tasks or a tag."""
    if filter not in (None, "overdue"):
        raise HTTPException(
            status_code=422,
            detail="Unsupported filter. Use filter=overdue.",
        )
    return TaskService.list_tasks(session, filter=filter, tag=tag)


@router.get("/{task_id}", response_model=TaskRead)
def get_task(task_id: int, session: Session = Depends(get_session)):
    """Get a specific task by ID."""
    return TaskService.get_task(session, task_id)


@router.patch("/{task_id}", response_model=TaskRead)
def update_task(
    task_id: int,
    task_update: TaskUpdate,
    session: Session = Depends(get_session),
):
    """Partially update a task with status-transition validation."""
    return TaskService.update_task(session, task_id, task_update)


@router.delete("/{task_id}")
def delete_task(task_id: int, session: Session = Depends(get_session)):
    """Delete a task by ID."""
    TaskService.delete_task(session, task_id)
    return {"message": "Task deleted successfully"}
