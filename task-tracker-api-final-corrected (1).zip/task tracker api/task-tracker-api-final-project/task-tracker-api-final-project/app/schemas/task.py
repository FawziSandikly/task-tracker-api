# Pydantic schemas for API request validation and response serialization
import json
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class TaskStatus(str, Enum):
    """Task status enum for schema validation."""
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"


def normalize_tags(tags: list[str]) -> list[str]:
    """Trim tags, reject empty values, and remove duplicates while preserving order."""
    normalized: list[str] = []
    for tag in tags:
        cleaned = tag.strip()
        if not cleaned:
            raise ValueError("Tags cannot be empty or whitespace.")
        if cleaned not in normalized:
            normalized.append(cleaned)
    return normalized


class TaskCreate(BaseModel):
    """Schema for creating a new task (POST request body)."""
    title: str = Field(..., min_length=1, max_length=255, description="Task title")
    description: str = Field(default="", max_length=1000, description="Task description")
    status: Optional[TaskStatus] = Field(default=None, description="Initial task status")
    due_date: Optional[datetime] = Field(default=None, description="Optional ISO 8601 due date")
    tags: list[str] = Field(default_factory=list, description="Optional task tags")

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, value: list[str]) -> list[str]:
        return normalize_tags(value)


class TaskUpdate(BaseModel):
    """Schema for partial task updates (PATCH request body)."""
    title: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    status: Optional[TaskStatus] = Field(None)
    due_date: Optional[datetime] = Field(default=None)
    tags: Optional[list[str]] = Field(default=None)

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, value: Optional[list[str]]) -> Optional[list[str]]:
        return None if value is None else normalize_tags(value)


class TaskRead(BaseModel):
    """Schema for API responses when returning task data."""
    id: int
    title: str
    description: str
    status: TaskStatus
    due_date: Optional[datetime]
    tags: list[str]
    is_overdue: bool
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="before")
    @classmethod
    def from_task_table(cls, value: Any) -> Any:
        if hasattr(value, "tags") and hasattr(value, "due_date"):
            raw_tags = value.tags or "[]"
            try:
                tags = json.loads(raw_tags)
            except (TypeError, json.JSONDecodeError):
                tags = []
            due_date = value.due_date
            if due_date is None:
                is_overdue = False
            else:
                if due_date.tzinfo is None:
                    now = datetime.utcnow()
                else:
                    now = datetime.now(timezone.utc)
                is_overdue = due_date < now and value.status != TaskStatus.DONE
            return {
                "id": value.id,
                "title": value.title,
                "description": value.description,
                "status": value.status,
                "due_date": due_date,
                "tags": tags,
                "is_overdue": is_overdue,
                "created_at": value.created_at,
                "updated_at": value.updated_at,
            }
        return value
