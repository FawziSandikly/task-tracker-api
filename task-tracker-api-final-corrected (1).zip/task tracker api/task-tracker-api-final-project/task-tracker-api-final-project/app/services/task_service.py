# Task service layer implementing transition validation and mid-course features
import json
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlmodel import Session, select

from app.models.task import TaskStatus, TaskTable
from app.schemas.task import TaskCreate, TaskUpdate


ALLOWED_TRANSITIONS = {
    TaskStatus.TODO: {TaskStatus.TODO, TaskStatus.IN_PROGRESS},
    TaskStatus.IN_PROGRESS: {TaskStatus.IN_PROGRESS, TaskStatus.DONE},
    TaskStatus.DONE: {TaskStatus.DONE},
}


def task_is_overdue(task: TaskTable) -> bool:
    """Return True for past-due tasks that are not completed."""
    if task.due_date is None or task.status == TaskStatus.DONE:
        return False
    if task.due_date.tzinfo is None:
        return task.due_date < datetime.utcnow()
    return task.due_date < datetime.now(timezone.utc)


class TaskService:
    """Service layer for task CRUD, validation, due dates, and tags."""

    @staticmethod
    def create_task(session: Session, task_create: TaskCreate) -> TaskTable:
        db_task = TaskTable(
            title=task_create.title,
            description=task_create.description,
            status=task_create.status or TaskStatus.TODO,
            due_date=task_create.due_date,
            tags=json.dumps(task_create.tags),
        )
        session.add(db_task)
        session.commit()
        session.refresh(db_task)
        return db_task

    @staticmethod
    def get_task(session: Session, task_id: int) -> TaskTable:
        task = session.get(TaskTable, task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        return task

    @staticmethod
    def list_tasks(
        session: Session,
        filter: str | None = None,
        tag: str | None = None,
    ) -> list[TaskTable]:
        tasks = session.exec(select(TaskTable)).all()
        if filter == "overdue":
            tasks = [task for task in tasks if task_is_overdue(task)]
        if tag is not None:
            wanted = tag.strip()
            tasks = [
                task for task in tasks
                if wanted in json.loads(task.tags or "[]")
            ]
        return tasks

    @staticmethod
    def validate_transition(current_status: TaskStatus, new_status: TaskStatus) -> bool:
        if new_status not in ALLOWED_TRANSITIONS[current_status]:
            allowed = ", ".join(s.value for s in ALLOWED_TRANSITIONS[current_status])
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Invalid transition from '{current_status.value}' "
                    f"to '{new_status.value}'. Allowed transitions: {allowed}"
                ),
            )
        return True

    @staticmethod
    def update_task(session: Session, task_id: int, task_update: TaskUpdate) -> TaskTable:
        db_task = TaskService.get_task(session, task_id)

        if task_update.status and task_update.status != db_task.status:
            TaskService.validate_transition(db_task.status, task_update.status)

        if task_update.title is not None:
            db_task.title = task_update.title
        if task_update.description is not None:
            db_task.description = task_update.description
        if task_update.status is not None:
            db_task.status = task_update.status
        if "due_date" in task_update.model_fields_set:
            db_task.due_date = task_update.due_date
        if task_update.tags is not None:
            db_task.tags = json.dumps(task_update.tags)

        db_task.updated_at = datetime.utcnow()
        session.add(db_task)
        session.commit()
        session.refresh(db_task)
        return db_task

    @staticmethod
    def delete_task(session: Session, task_id: int) -> None:
        db_task = TaskService.get_task(session, task_id)
        session.delete(db_task)
        session.commit()
