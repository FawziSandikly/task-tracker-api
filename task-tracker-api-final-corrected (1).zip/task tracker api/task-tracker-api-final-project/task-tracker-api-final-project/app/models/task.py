# SQLModel task table definition for SQLite persistence
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlmodel import Field, SQLModel


class TaskStatus(str, Enum):
    """Allowed task status values per ADR-0001."""
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"


class TaskTable(SQLModel, table=True):
    """SQLite table model for task persistence."""

    __tablename__ = "tasks"

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(index=True)
    description: str = ""
    status: TaskStatus = Field(default=TaskStatus.TODO)
    due_date: Optional[datetime] = None
    # Tags are stored as a JSON array in SQLite TEXT for lightweight persistence.
    tags: str = "[]"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
